import React, { useState } from 'react'
import { Disclosure, DisclosureButton, DisclosurePanel, Menu, MenuButton, MenuItems, MenuItem } from '@headlessui/react';
import { ChevronDownIcon } from '@heroicons/react/20/solid';
import { Bars3Icon, BellIcon, XMarkIcon } from '@heroicons/react/24/outline'

const navigation = [
    // { name: 'Dashboard', href: '#' },
    { name: 'Financing', href: '#' },
    { name: 'Reviews', href: '#' },
    { name: 'Inspiration', href: '#' },
    { name: 'Contact', href: '#' },
]

function classNames(...classes) {
    return classes.filter(Boolean).join(' ')
}


const Navbar = () => {

    return (


        <Disclosure as="nav" className="bg-white">
            <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
                <div className="relative flex h-16 items-center justify-between ">
                    <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
                        {/* Mobile menu button*/}
                        <DisclosureButton className="group relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                            <span className="absolute -inset-0.5" />
                            <span className="sr-only">Open main menu</span>
                            <Bars3Icon aria-hidden="true" className="block h-6 w-6 group-data-[open]:hidden" />
                            <XMarkIcon aria-hidden="true" className="hidden h-6 w-6 group-data-[open]:block" />
                        </DisclosureButton>
                    </div>
                    <div className="flex flex-1 items-center justify-center sm:items-stretch ">
                        <div className="hidden sm:ml-6 sm:block">
                            <div className="flex space-x-4">

                                {/* Dropdown menu for Dashboard */}
                                <Menu as="div" className="relative inline-block text-left">
                                    <div >
                                        <MenuButton
                                            className="inline-flex justify-center rounded-md px-3 py-2 text-sm font-medium text-gray-700 hover:text-green-400"
                                        >
                                            Products
                                            <ChevronDownIcon className="-mr-1 ml-2 h-5 w-5" aria-hidden="true" />
                                        </MenuButton>
                                    </div>
                                    <MenuItems className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                                        <MenuItem>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                Carpet
                                            </a>
                                        </MenuItem>
                                        <MenuItem>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                Carpet Tile
                                            </a>
                                        </MenuItem>
                                    </MenuItems>
                                </Menu>
                                {/* Dropdown mwnu for Servides */}
                                <Menu as="div" className="relative inline-block text-left">
                                    <div >
                                        <MenuButton
                                            className="inline-flex justify-center rounded-md px-3 py-2 text-sm font-medium text-gray-700 hover:text-green-400"
                                        >
                                            Services
                                            <ChevronDownIcon className="-mr-1 ml-2 h-5 w-5" aria-hidden="true" />
                                        </MenuButton>
                                    </div>
                                    <MenuItems className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                                        <MenuItem>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                Kitchen Remodeling
                                            </a>
                                        </MenuItem>
                                        <MenuItem>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                Bathroom Remodeling
                                            </a>
                                        </MenuItem>
                                    </MenuItems>
                                </Menu>
                                {navigation.map((item, index) => (
                                    <a
                                        key={item.name}
                                        href={item.href}
                                        aria-current={item.current ? 'page' : undefined}
                                        className={classNames(
                                            'text-gray-700',
                                            'rounded-md px-3 py-2 text-sm font-medium',
                                            'hover:text-green-400'
                                        )}
                                    >
                                        {item.name}
                                    </a>
                                ))}
                                {/* Dropdown for About Us */}
                                <Menu as="div" className="relative inline-block text-left">
                                    <div >
                                        <MenuButton
                                            className="inline-flex justify-center rounded-md px-3 py-2 text-sm font-medium text-gray-700 hover:text-green-400"
                                        >
                                            About Us
                                            <ChevronDownIcon className="-mr-1 ml-2 h-5 w-5" aria-hidden="true" />
                                        </MenuButton>
                                    </div>
                                    <MenuItems className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                                        <MenuItem>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                Location
                                            </a>
                                        </MenuItem>
                                        <MenuItem>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                Shop At Home
                                            </a>
                                        </MenuItem>
                                    </MenuItems>
                                </Menu>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <DisclosurePanel className="sm:hidden">
                <div className="space-y-1 px-2 pb-3 pt-2">
                    {navigation.map((item, index) => (
                        <DisclosureButton
                            key={item.name}
                            as="a"
                            href={item.href}
                            aria-current={item.current ? 'page' : undefined}
                            className={classNames(
                                'text-gray-700',
                                'rounded-md px-3 py-2 text-sm font-medium',
                                'hover:text-green-400'
                            )}
                        >
                            {item.name}
                        </DisclosureButton>
                    ))}
                </div>
            </DisclosurePanel>
        </Disclosure>
    )
}


export default Navbar
