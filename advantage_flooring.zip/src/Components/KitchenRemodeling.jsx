import React from "react";

const KitchenRemodeling = () => {
    return (
        <>
            <div className="relative">
                <img
                    className="w-screen h-60 object-cover"
                    src="https://p1.pxfuel.com/preview/71/599/650/kitchen-real-estate-design-residential.jpg"
                />
                <h1 className="absolute text-3xl text-slate-50 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 font-extrabold">
                    KITCHEN REMODELING
                </h1>
                <h2 className="absolute text-xl italic  bg-lime-500 p-3 m-auto text-white bottom-4 left-1/2 -translate-x-1/2 font-bold">
                    Request a free estimate !!
                </h2>
            </div>
        </>
    );
};

export default KitchenRemodeling;
