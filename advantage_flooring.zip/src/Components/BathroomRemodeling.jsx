import React from "react";

const BathroomRemodeling = () => {
    return (
        <>
            <div className="relative">
                <img
                    className="w-screen h-60 object-cover"
                    src="https://images.pexels.com/photos/496706/pexels-photo-496706.jpeg?w=940&h=650&auto=compress&cs=tinysrgb"
                />
                <h1 className="absolute text-3xl text-slate-50 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 font-extrabold">
                    BATHROOM REMODELING
                </h1>
                <h2 className="absolute text-xl  text-white bg-lime-500 p-3 m-auto bottom-4 left-1/2 -translate-x-1/2 font-bold">
                    Request a free estimate
                </h2>
            </div>
        </>
    );
};

export default BathroomRemodeling;
