import React from "react";

const Inspiration = () => {
    return <div>Inspiration</div>;
};

export default Inspiration;
